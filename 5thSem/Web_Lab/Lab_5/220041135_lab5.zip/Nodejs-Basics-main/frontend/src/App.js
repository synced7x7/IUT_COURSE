import { useCallback, useEffect, useState } from "react";
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import api from "./api/axios";
import CreateWorkout from "./components/CreateWorkout";
import EditWorkout from "./components/EditWorkout";
import LandingPage from "./components/LandingPage";
import SingleWorkout from "./components/SingleWorkout";
import WorkoutList from "./components/WorkoutList";

function App() {
  const [workouts, setWorkouts] = useState([]);
  const [selectedWorkout, setSelectedWorkout] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const fetchWorkouts = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const res = await api.get("/workouts");
      setWorkouts(res.data);
    } catch (err) {
      setError(err.response?.data?.error || "Failed to load workouts");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWorkouts();
  }, [fetchWorkouts]);

  const handleCreate = async (payload) => {
    setError("");

    try {
      const res = await api.post("/workouts", payload);
      setWorkouts((prev) => [res.data, ...prev]);
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        error: err.response?.data?.error || "Failed to create workout"
      };
    }
  };

  const handleUpdate = async (id, payload) => {
    setError("");

    try {
      await api.patch(`/workouts/${id}`, payload);
      setSelectedWorkout(null);
      fetchWorkouts();
      return { ok: true };
    } catch (err) {
      return {
        ok: false,
        error: err.response?.data?.error || "Failed to update workout"
      };
    }
  };

  const handleDelete = async (id) => {
    setError("");

    try {
      await api.delete(`/workouts/${id}`);
      setWorkouts((prev) => prev.filter((item) => item._id !== id));
    } catch (err) {
      setError(err.response?.data?.error || "Failed to delete workout");
    }
  };

  const handleEditSelect = (workout) => {
    setSelectedWorkout(workout);
    navigate("/edit");
  };

  return (
    <div>
      <header>
        <nav>
          <Link to="/">Home</Link>
        </nav>
      </header>

    

      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/create" element={<CreateWorkout onCreate={handleCreate} />} />
        <Route
          path="/list"
          element={
            <div>
              <WorkoutList
                workouts={workouts}
                onEdit={handleEditSelect}
                onDelete={handleDelete}
              />
            </div>
          }
        />
        <Route
          path="/edit"
          element={
            selectedWorkout ? (
              <EditWorkout
                workout={selectedWorkout}
                onCancel={() => setSelectedWorkout(null)}
                onSave={handleUpdate}
              />
            ) : (
              <div>
                <p>Select a workout from the list to edit.</p>
                <Link to="/list">Go to Workout List</Link>
              </div>
            )
          }
        />
        <Route path="/find" element={<SingleWorkout />} />
      </Routes>
    </div>
  );
}

export default App;
