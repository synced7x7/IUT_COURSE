import { Link } from "react-router-dom";

const LandingPage = () => {
  return (
    <div>
      <h2>Workout Manager</h2>
      <p>Select a page:</p>
      <nav>
        <ul>
          <li>
            <Link to="/create">Create Workout</Link>
          </li>
          <li>
            <Link to="/list">Workout List</Link>
          </li>
          <li>
            <Link to="/edit">Edit Workout</Link>
          </li>
          <li>
            <Link to="/find">Find Workout</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default LandingPage;
