import { useEffect, useState } from "react";

const EditWorkout = ({ workout, onCancel, onSave }) => {
  const [title, setTitle] = useState("");
  const [load, setLoad] = useState("");
  const [reps, setReps] = useState("");
  const [difficulty, setDifficulty] = useState("medium");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!workout) {
      return;
    }

    setTitle(workout.title || "");
    setLoad(workout.load ?? "");
    setReps(workout.reps ?? "");
    setDifficulty(workout.difficulty || "medium");
    setError("");
  }, [workout]);

  if (!workout) {
    return null;
  }

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    const result = await onSave(workout._id, {
      title,
      load: Number(load),
      reps: Number(reps),
      difficulty
    });

    if (!result.ok) {
      setError(result.error);
    }
  };

  return (
    <div>
      <h4>Edit Workout</h4>
      <form onSubmit={handleSubmit}>
        <label>
          Title
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </label>

        <label>
          Load
          <input
            value={load}
            onChange={(e) => setLoad(e.target.value)}
          />
        </label>

        <label>
          Reps
          <input
            value={reps}
            onChange={(e) => setReps(e.target.value)}
          />
        </label>

        <label>
          Difficulty
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
          >
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </label>

        {error && <p>{error}</p>}

        <button type="submit">Save changes</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </form>
    </div>
  );
};

export default EditWorkout;
