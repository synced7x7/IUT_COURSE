import { useState } from "react";

const CreateWorkout = ({ onCreate }) => {
  const [title, setTitle] = useState("");
  const [load, setLoad] = useState("");
  const [reps, setReps] = useState("");
  const [difficulty, setDifficulty] = useState("medium");
  const [error, setError] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    const result = await onCreate({
      title,
      load: Number(load),
      reps: Number(reps),
      difficulty
    });

    if (result.ok) {
      setTitle("");
      setLoad("");
      setReps("");
      setDifficulty("medium");
      return;
    }

    setError(result.error);
  };

  return (
    <div>
      <h3>Create Workout</h3>

      <form onSubmit={handleSubmit}>
        <label>
          Title
          <input
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </label>

        <label>
          Load
          <input
            placeholder="Load"
            value={load}
            onChange={(e) => setLoad(e.target.value)}
          />
        </label>

        <label>
          Reps
          <input
            placeholder="Reps"
            value={reps}
            onChange={(e) => setReps(e.target.value)}
          />
        </label>

        <label>
          Difficulty
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
          >
            <option value="easy">Easy</option>
            <option value="medium">Medium</option>
            <option value="hard">Hard</option>
          </select>
        </label>

        {error && <p>{error}</p>}

        <button type="submit">Add Workout</button>
      </form>
    </div>
  );
};

export default CreateWorkout;
