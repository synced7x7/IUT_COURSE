const WorkoutList = ({ workouts, onEdit, onDelete }) => {
  return (
    <div>
      <h3>All Workouts</h3>

      {workouts.length === 0 && <p>No workouts found.</p>}

      {workouts.map((workout) => (
        <div key={workout._id}>
          <h4>{workout.title}</h4>
          <p>Load: {workout.load}</p>
          <p>Reps: {workout.reps}</p>
          <p>Difficulty: {workout.difficulty}</p>

          <button onClick={() => onEdit(workout)}>Edit</button>
          <button onClick={() => onDelete(workout._id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default WorkoutList;
