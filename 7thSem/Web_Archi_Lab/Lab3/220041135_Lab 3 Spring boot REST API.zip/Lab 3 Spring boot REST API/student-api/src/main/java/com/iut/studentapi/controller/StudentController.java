package com.iut.studentapi.controller;

import com.iut.studentapi.model.Stats;
import com.iut.studentapi.model.Student;
import com.iut.studentapi.service.StudentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * StudentController — the web (presentation) layer.
 * Maps HTTP requests to service calls and returns JSON responses.
 */
@RestController
@RequestMapping("/api/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }
    private final Stats stats = new Stats();
    // ---- IMPLEMENTED (Part A: run and test these) ----

    // GET /api/students
    @GetMapping
    public List<Student> getAllStudents(@RequestBody(required = false) String department) {
        List<Student> all = studentService.getAllStudents();
        if (department == null) { return all; }

        return all.stream().filter(
                student -> student.getDepartment().equalsIgnoreCase(department)).collect(Collectors.toList());
    }

    // GET /api/students/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
        Student student = studentService.getStudentById(id);
        if (student != null) {
            return ResponseEntity.ok(student);
        }
        return ResponseEntity.notFound().build();
    }

    // POST /api/students
    @PostMapping
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        Student created = studentService.createStudent(student);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // ---- TODO (Part B): complete the update and delete endpoints ----

    /**
     * TODO (Part B, Task B1): PUT /api/students/{id}
     *
     * - Add the correct mapping annotation for an update.
     * - Read the id from the path and the student from the request body.
     * - Call studentService.updateStudent(...).
     * - Return 200 OK with the updated student, or 404 Not Found.
     */
    // (write the update endpoint here)

    @PutMapping("/{id}")
    public ResponseEntity<Student> updateStudent(@PathVariable Long id, @RequestBody Student student) {
        Student updated = studentService.updateStudent(id, student);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        }
        return ResponseEntity.notFound().build();
    }

    /**
     * TODO (Part B, Task B2): DELETE /api/students/{id}
     *
     * - Add the correct mapping annotation for a delete.
     * - Call studentService.deleteStudent(...).
     * - Return 204 No Content on success, or 404 Not Found.
     */
    // (write the delete endpoint here)
    @DeleteMapping("/{id}")
    public ResponseEntity<Student> deleteStudent(@PathVariable Long id) {
        boolean deleted = studentService.deleteStudent(id);
        if(deleted) return ResponseEntity.noContent().build();
        return ResponseEntity.notFound().build();
    }

    @GetMapping("/search")
    public List<Student> searchByName(@RequestParam String name) {
        return studentService.searchByName(name);
    }

    @GetMapping("/stats")
    public Stats getStats() {
        return studentService.getStats();
    }


}
