package com.iut.studentapi.service;

import com.iut.studentapi.model.Stats;
import com.iut.studentapi.model.Student;
import com.iut.studentapi.repository.StudentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * StudentService — the business-logic layer.
 * Sits between the controller and the repository.
 */
@Service
public class StudentService {

    private final StudentRepository studentRepository;

    // Constructor injection (no @Autowired needed when there is a single constructor)
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    // ---- IMPLEMENTED (Part A) ----

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public Student createStudent(Student student) {
        validateStudent(student);

        return studentRepository.save(student);
    }

     private void validateStudent(Student student) {
        if (student.getName() == null || student.getName().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Name is required");
        }
         if (student.getStudentId() == null || student.getStudentId().isEmpty()) {
             throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Student ID is required");
         }
         if (student.getCgpa()<0.0 && student.getCgpa()>4.0) {
             throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "CGPA must be in between 0 and 4");
         }

         for (Student ex : getAllStudents()) {
             if(ex.getStudentId().equals(student.getStudentId())) {
                 throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Duplicate id exists");
             }
         }
     }

    // ---- TODO (Part B): add updateStudent and deleteStudent methods here ----

    /**
     * TODO (Part B, Task B1): updateStudent
     *
     * Delegate to studentRepository.updateById(...).
     * Return the updated student, or null if not found.
     */
    public Student updateStudent(Long id, Student updated) {
        return studentRepository.updateById(id, updated);
    }


    /**
     * TODO (Part B, Task B2): deleteStudent
     *
     * Delegate to studentRepository.deleteById(...).
     * Return true if deleted, false if not found.
     */

    public boolean deleteStudent(long id) {
        return studentRepository.deleteById(id);
    }

    public List<Student> searchByName(String name) {
        return getAllStudents().stream()
                .filter(s -> s.getName().toLowerCase().contains(name.toLowerCase())).toList()
                ;
    }

    public Stats getStats() {
        List<Student> all = getAllStudents();

        int countStudents=0;
        float avgcgpa = 0;
        int activeCount = 0;
        int inactiveCount = 0;
        for (Student student : all) {
            avgcgpa+=(float)student.getCgpa();
            countStudents++;
            if(student.isActive()) activeCount++;
        }
        avgcgpa = avgcgpa/countStudents;
        inactiveCount = countStudents-activeCount;
        return new Stats(countStudents, null, avgcgpa, activeCount, inactiveCount);
    }


}
