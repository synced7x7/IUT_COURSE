package com.iut.studentapi.model;

/**
 * Student — the domain model.
 */
public class Student {

    private Long id;
    private String name;
    private String studentId;   // e.g. "220041101"
    private String department;  // e.g. "CSE", "EEE", "MCE", "CEE", "BTM"
    private int batch;          // e.g. 22
    private double cgpa;        // 0.00 – 4.00
    private boolean active;     // currently enrolled?

    public Student() {}

    public Student(Long id, String name, String studentId, String department,
                   int batch, double cgpa, boolean active) {
        this.id = id;
        this.name = name;
        this.studentId = studentId;
        this.department = department;
        this.batch = batch;
        this.cgpa = cgpa;
        this.active = active;
    }

    // ---- Getters and Setters ----

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public int getBatch() { return batch; }
    public void setBatch(int batch) { this.batch = batch; }

    public double getCgpa() { return cgpa; }
    public void setCgpa(double cgpa) { this.cgpa = cgpa; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}
