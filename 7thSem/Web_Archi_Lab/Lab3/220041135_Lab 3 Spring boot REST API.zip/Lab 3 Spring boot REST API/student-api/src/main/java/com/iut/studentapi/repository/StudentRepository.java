package com.iut.studentapi.repository;

import com.iut.studentapi.model.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * StudentRepository — the data-access layer.
 * Stores students in a plain ArrayList (no database).
 */
@Repository
public class StudentRepository {

    private final List<Student> students = new ArrayList<>();
    private long nextId = 1;

    // Pre-load sample data so you can test immediately
    public StudentRepository() {
        students.add(new Student(nextId++, "Ahmed Rahman",   "220041101", "CSE", 22, 3.72, true));
        students.add(new Student(nextId++, "Fatima Akter",   "220041205", "CSE", 22, 3.85, true));
        students.add(new Student(nextId++, "Omar Hasan",     "210042301", "EEE", 21, 3.45, true));
        students.add(new Student(nextId++, "Khadijah Yusuf", "200043102", "MCE", 20, 3.60, false));
    }

    // Return all students
    public List<Student> findAll() {
        return students;
    }

    // Find a student by internal id; returns null if not found
    public Student findById(Long id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    // Save a new student, auto-assigning an id
    public Student save(Student student) {
        student.setId(nextId++);
        students.add(student);
        return student;
    }

    // ---- TODO (Part B): add updateById and deleteById methods here ----
    public Student updateById(Long id, Student updated) {
        for (Student s: students) {
            if(s.getId().equals(id)) {
                s.setName(updated.getName());
                s.setDepartment(updated.getDepartment());
                s.setBatch(updated.getBatch());
                s.setCgpa(updated.getCgpa());
                s.setActive(updated.isActive());
                return s;
            }
        }
        return null;
    }

    public boolean deleteById(Long id) {
        return students.remove(findById(id));
    }
    /**
     * TODO (Part B, Task B1): updateById
     *
     * Find the student with the given id in the list.
     * If found, update its fields from the incoming Student object
     * and return the updated student. If not found, return null.
     *
     * Hint: loop through the list, match by id, then use setters.
     */

    /**
     * TODO (Part B, Task B2): deleteById
     *
     * Remove the student with the given id from the list.
     * Return true if removed, false if not found.
     *
     * Hint: use students.removeIf(...)
     */





}
