package com.iut.studentapi.model;

import java.util.Map;

public class Stats {
    private int totalStudents;
    private Map<String, Integer> byDept;
    private float avgCgpa;
    private int activeCount;
    private int inactiveCount;

    public Stats() {}

    public Stats(int totalStudents, Map<String, Integer> byDept, float avgCgpa, int activeCount, int inactiveCount) {
        this.totalStudents = totalStudents;
        this.avgCgpa = avgCgpa;
        this.byDept = byDept;
        this.activeCount = activeCount;
        this.inactiveCount = inactiveCount;
    }

    public int getTotalStudents(){ return totalStudents; }
    public Map<String, Integer> getByDept(){ return byDept; }
    public float getAvgCgpa(){ return avgCgpa; }
    public int getActiveCount(){ return activeCount; }
    public int getInactiveCount(){ return inactiveCount; }

    public void setTotalStudents(int totalStudents){ this.totalStudents = totalStudents; }
    public void setByDept(Map<String, Integer> byDept){ this.byDept = byDept; }
    public void setActiveCount(int activeCount){ this.activeCount = activeCount; }
    public void setInactiveCount(int inactiveCount){ this.inactiveCount = inactiveCount; }
}
