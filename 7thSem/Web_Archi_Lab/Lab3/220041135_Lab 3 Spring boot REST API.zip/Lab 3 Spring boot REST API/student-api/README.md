# CSE 4635 — Lab 03: IUT Student REST API (Starter Code)

A Spring Boot REST API with in-memory storage (no database).

## Layers
Controller → Service → Repository

## Running
```
./mvnw spring-boot:run
```

## Testing
- Swagger UI: http://localhost:8080/swagger-ui.html
- Postman: import and test endpoints manually
