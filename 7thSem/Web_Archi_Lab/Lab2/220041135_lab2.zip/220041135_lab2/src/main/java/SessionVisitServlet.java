import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/httpSessionServlet")
public class SessionVisitServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            session = request.getSession(true);
            session.setAttribute("visitCount", 0);
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<html><body>");
            out.println("<h2>Welcome! Newcomer</h2>");
            out.println("</body></html>");
        } else {
            int visitCount = (int) session.getAttribute("visitCount");
            visitCount++;
            session.setAttribute("visitCount", visitCount);
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<html><body>");
            out.println("<h2>Welcome! Newcomer</h2>");
            out.println("<p>You have visited this page " + visitCount + " times.</p>");
            out.println("</body></html>");
            out.println("<table>");
            out.println("<tr><th>Session ID</th><td>" + session.getId() + "</td></tr>");
            out.println("<tr><th>Creation Time</th><td>" + session.getCreationTime() + "</td></tr>");
            out.println("<tr><th>Last Accessed Time</th><td>" + session.getLastAccessedTime() + "</td></tr>");
            out.println("</table>");

            out.println("</br>");
            out.println("<form action='endSessionServlet' method='GET'>");
            out.println("<input type='submit' value='End Session'>");
            out.println("</form>");

            out.println("</body></html>");
        }

    }
}
