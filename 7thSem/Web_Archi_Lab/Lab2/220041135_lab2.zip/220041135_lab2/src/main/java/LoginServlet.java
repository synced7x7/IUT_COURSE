import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    @SuppressWarnings("unchecked")
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = trim(request.getParameter("username"));
        String password = trim(request.getParameter("password"));

        ServletContext ctx = getServletContext();
        HashMap<String, String> users = (HashMap<String, String>) ctx.getAttribute("users");
        if (users == null) {
            users = new HashMap<>();
            ctx.setAttribute("users", users);
        }

        boolean isRegister = request.getParameter("register") != null;
        boolean isLogin = request.getParameter("login") != null;

        if (isRegister) {
            if (username.isEmpty() || password.isEmpty()) {
                response.sendRedirect("login.jsp?error=Username+and+password+required");
                return;
            }
            if (users.containsKey(username)) {
                response.sendRedirect("login.jsp?error=Username+already+taken");
                return;
            }
            users.put(username, password);
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);
            response.sendRedirect("homepage.jsp");
            return;
        }

        if (isLogin) {
            if (!users.containsKey(username)) {
                response.sendRedirect("login.jsp?error=User+not+found.+Please+register");
                return;
            }
            if (!users.get(username).equals(password)) {
                response.sendRedirect("login.jsp?error=Invalid+credentials");
                return;
            }
            HttpSession session = request.getSession(true);
            session.setAttribute("username", username);
            response.sendRedirect("homepage.jsp");
            return;
        }

        response.sendRedirect("login.jsp?error=Invalid+action");
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
