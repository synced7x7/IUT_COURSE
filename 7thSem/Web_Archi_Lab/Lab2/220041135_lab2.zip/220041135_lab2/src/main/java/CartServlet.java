import model.CartBean;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        String item = request.getParameter("item");

        HttpSession session = request.getSession(true);
        CartBean cart = (CartBean) session.getAttribute("cart");
        if (cart == null) {
            cart = new CartBean();
            session.setAttribute("cart", cart);
        }

        if ("add".equals(action)) {
            cart.addItem(item);
        } else if ("increment".equals(action)) {
            cart.incrementItem(item);
        } else if ("decrement".equals(action)) {
            cart.decrementItem(item);
        }

        String redirect = "homepage.jsp";
        if ("increment".equals(action) || "decrement".equals(action)) {
            redirect = "cart.jsp";
        }
        response.sendRedirect(redirect);
    }
}
