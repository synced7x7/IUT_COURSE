package model;
import java.util.HashMap;
import java.util.Map;

public class CartBean {
    private final Map<String, Integer> items = new HashMap<>();
    private final Map<String, Integer> prices = new HashMap<>();

    public CartBean() {
        prices.put("Wireless Mouse",25);
        prices.put("Mechanical Keyboard",75);
        prices.put("USB-C Hub",40);
    }

    public void addItem(String name) {
        incrementItem(name);
    }

    public void incrementItem(String name) {
        if (name == null) return;
        items.put(name, items.getOrDefault(name,0) +1);
    }

    public void decrementItem(String name) {
        if (name == null) return;
        int qty = items.getOrDefault(name,0) -1;
        if (qty <=0) {
            items.remove(name);
        } else {
            items.put(name, qty);
        }
    }

    public Map<String, Integer> getItems() {
        return items;
    }

    public int getTotalCount() {
        int total =0;
        for (int qty : items.values()) {
            total += qty;
        }
        return total;
    }

    public int getTotalPrice() {
        int total =0;
        for (Map.Entry<String, Integer> e : items.entrySet()) {
            total += getPrice(e.getKey()) * e.getValue();
        }
        return total;
    }

    public int getPrice(String name) {
        return prices.getOrDefault(name,0);
    }
}
