import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class RandomServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String num1Str = request.getParameter("number1");
        String num2Str = request.getParameter("number2");

        int lower = Integer.parseInt(num1Str);
        int upper = Integer.parseInt(num2Str);

        Random rand = new Random();
        int randomNum = rand.nextInt(upper - lower + 1) + lower;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>Random number between " + lower + " and " + upper + " is: " + randomNum + "</h2>");
        out.println("</body></html>");
    }
}