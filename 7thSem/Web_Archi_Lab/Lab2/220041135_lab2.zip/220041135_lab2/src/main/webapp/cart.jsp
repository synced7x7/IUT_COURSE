<%@ page import="java.util.Map" %>
<%@ page import="model.CartBean" %>
<html>
<head>
  <title>Cart</title>
</head>
<body>
  <%
 CartBean cart = (CartBean) session.getAttribute("cart");
%>
<h2>Your Cart</h2>
<table border="1" cellpadding="6">
  <tr>
    <th>Item</th>
    <th>Unit Price</th>
    <th>Quantity</th>
    <th>Subtotal</th>
    <th>Actions</th>
  </tr>
  <%
    if (cart != null) {
      for (Map.Entry<String, Integer> entry : cart.getItems().entrySet()) {
        String name = entry.getKey();
        int qty = entry.getValue();
        if (qty <=0) continue;
        int price = cart.getPrice(name);
        int subtotal = price * qty;
  %>
  <tr>
    <td><%= name %></td>
    <td>\৳<%= price %></td>
    <td><%= qty %></td>
    <td>\৳<%= subtotal %></td>
    <td>
      <a href="CartServlet?action=increment&item=<%= name.replace(" ", "+") %>">+</a>
      <a href="CartServlet?action=decrement&item=<%= name.replace(" ", "+") %>">\-</a>
    </td>
  </tr>
  <%
      }
    }
  %>
  <tr>
    <td colspan="3"><strong>Total</strong></td>
    <td colspan="2">\৳<%= cart == null ?0 : cart.getTotalPrice() %></td>
  </tr>
</table>

<p>
  <a href="homepage.jsp">Back to
  </a>