<html>
<head>
    <title>Login</title>
</head>
<body>
<h2>Login \| Register</h2>
<%
    String error = request.getParameter("error");
    if (error != null && !error.isEmpty()) {
%>
<p style="color:red;"><%= error %></p>
<%
    }
%>
<form method="post" action="LoginServlet">
    <label>Username:</label>
    <input type="text" name="username" /><br/>
    <label>Password:</label>
    <input type="password" name="password" /><br/>
    <button type="submit" name="login">Login</button>
    <button type="submit" name="register">Register</button>
</form>
</body>
</html>
