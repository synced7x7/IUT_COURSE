<%@ page import="model.CartBean" %>
<html>
<head>
  <title>Shop</title>
</head>
<body>
<%
  String username = (String) session.getAttribute("username");
  CartBean cart = (CartBean) session.getAttribute("cart");
  int count = cart == null ?0 : cart.getTotalCount();
%>
<h2>Welcome, <%= username == null ? "Guest" : username %>\!</h2>
<p>Cart Items: <%= count %></p>

<h3>Products</h3>
<ul>
  <li>Wireless Mouse — \৳25 <a href="CartServlet?action=add&item=Wireless+Mouse">Add to Cart</a>
  </li>
  <li>Mechanical Keyboard — \৳75 <a href="CartServlet?action=add&item=Mechanical+Keyboard">Add to Cart</a>
  </li>
  <li>USB\-C Hub — \৳40 <a href="CartServlet?action=add&item=USB-C+Hub">Add to Cart</a>
  </li>
</ul>

<p>
  <a href="cart.jsp">View Cart</a> \|
  <a href="LogoutServlet">Logout</a>
</p>
</body>
</html>
