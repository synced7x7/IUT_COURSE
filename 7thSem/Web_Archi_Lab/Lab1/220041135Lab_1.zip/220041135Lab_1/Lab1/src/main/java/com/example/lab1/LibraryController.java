package com.example.lab1;

import java.util.List;

/**
 * LibraryController.java - The CONTROLLER layer.
 * It connects the View and the Model:
 * - Receives user actions from the View
 * - Calls the Model to get or change data
 * - Tells the View what to display
 *
 * The Controller NEVER prints to the console directly.
 * The Controller NEVER stores data itself.
 */
public class LibraryController {

    // References to Model and View
    private final Library model;
    private final LibraryView view;

    /** Constructor: receives both dependencies. */
    public LibraryController(Library model,
            LibraryView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Main application loop.
     * Keeps showing the menu until the user exits.
     */
    public void run() {
        boolean running = true;
        while (running) {
            // Step 1: View shows menu, returns choice
            int choice = view.showMenu();

            // Step 2: Controller decides what to do
            switch (choice) {
                case 1:
                    handleViewAll();
                    break;
                case 2:
                    handleSearchByIsbn();
                    break;
                case 3:
                    handleCheckOut();
                    break;
                case 4:
                    handleAvailability();
                    break;
                case 5:
                    running = false;
                    view.showMessage("Goodbye!");
                    break;
                case 6:
                    handleReturn();
                    break;
                case 7:
                    handleAddNewBook();
                    view.showMessage("Book added!");
                    break;
                case 8:
                    handleSearchByAuthor();
                    break;
                case 9:
                    handleViewCheckedOut();
                    break;
                default:
                    view.showMessage(
                            "Invalid choice. Try again.");
            }
        }
    }

    // ── Private handler methods ──
    private void handleViewCheckedOut() {
        List<Book> books = model.getCheckedOutBooks();
        if(books.isEmpty()) {
            view.showMessage("No books found!");
            return;
        }

        view.showBookList(books);
    }


    private void handleAddNewBook() {
        String isbn = view.askIsbn();
        String title = view.askTitle();
        String author = view.askAuthor();

        model.addBook(new Book(isbn, title, author));
    }

    private void handleSearchByAuthor() {
        String author = view.askAuthor();
        List<Book> books = model.getBooksByAuthor(author);
        if(books.isEmpty()) {
            view.showMessage("No books found!");
            return;
        }
        view.showBookList(books);
    }

    /** Gets all books from Model, sends to View. */
    private void handleViewAll() {
        view.showBookList(model.getAllBooks());
    }

    /** Asks View for ISBN, queries Model, shows result. */
    private void handleSearchByIsbn() {
        String isbn = view.askIsbn();
        Book book = model.findByIsbn(isbn);
        if (book != null) {
            view.showBookDetails(book);
        } else {
            view.showMessage(
                    "No book found with ISBN: " + isbn);
        }
    }

    /** Asks for ISBN, checks out if available. */
    private void handleCheckOut() {
        String isbn = view.askIsbn();
        Book book = model.findByIsbn(isbn);
        if (book == null) {
            view.showMessage(
                    "No book found with ISBN: " + isbn);
        } else if (book.isCheckedOut()) {
            view.showMessage(
                    "Sorry, that book is already checked out.");
        } else {
            book.checkOut();
            view.showMessage("Successfully checked out: "
                    + book.getTitle());
        }
    }

    /** Gets counts from Model, sends to View. */
    private void handleAvailability() {
        int available = model.getAvailableCount();
        int total = model.getTotalCount();
        view.showAvailability(available, total);
    }

    private void handleReturn() {
        String isbn = view.askIsbn();
        Book book = model.findByIsbn(isbn);
        if (book == null) {
            view.showMessage(
                    "No book found with ISBN: " + isbn);
        } else if (!book.isCheckedOut()) {
            view.showMessage(
                    "Invalid. The book is not in your possession");
        } else {
            book.returnBook();
            view.showMessage("Successfully returned book: "
                             + book.getTitle());
        }
    }

}