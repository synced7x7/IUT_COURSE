import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
} from 'react-native';

const GROQ_API_KEY = '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';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL = 'llama-3.3-70b-versatile';

// Renders text with **bold** markdown support
const MarkdownText = ({ text, style }) => {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return (
    <Text style={style}>
      {parts.map((part, i) =>
        part.startsWith('**') && part.endsWith('**') ? (
          <Text key={i} style={{ fontWeight: 'bold' }}>
            {part.slice(2, -2)}
          </Text>
        ) : (
          <Text key={i}>{part}</Text>
        )
      )}
    </Text>
  );
};

export default function App() {
  const [messages, setMessages] = useState([
    {
      id: '1',
      role: 'user',
      content: 'Hello, can you tell me how to print something in react native',
    },
    {
      id: '2',
      role: 'assistant',
      content:
        "To print something in a React Native application, you can use the 'printing' library. However, it's essential to note that printing functionality is not directly available in React Native. The 'printing' library you can use for this is not an official library but rather one that has been contributed by the community.\n\nHere's a step-by-step guide to print something in a React Native application:\n\n**Installing printing library:**\n\n1. Run 'npm install react-native-printing' in your terminal (or 'yarn add react-native-printing' if you're using Yarn).\n\n2. Run 'npx react-native link react-native-printing' to link the library to your project.\n\n**Example Code to Print:**",
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollViewRef = useRef(null);

  const sendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed || isLoading) return;

    const userMessage = { id: Date.now().toString(), role: 'user', content: trimmed };
    const updatedMessages = [...messages, userMessage];

    setMessages(updatedMessages);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch(GROQ_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${GROQ_API_KEY}`,
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          model: MODEL,
          messages: updatedMessages.map(({ role, content }) => ({ role, content })),
          max_tokens: 1024,
          temperature: 0.7,
        }),
      });

      const data = await response.json();
      console.log(JSON.stringify(data)); 

      if (!response.ok) {
        throw new Error(data.error?.message || 'API request failed');
      }

      const aiContent = data.choices?.[0]?.message?.content;
      if (aiContent) {
        setMessages(prev => [
          ...prev,
          { id: (Date.now() + 1).toString(), role: 'assistant', content: aiContent },
        ]);
      }
    } catch (e) {
      setMessages(prev => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: '⚠️ Something went wrong. Check your API key and internet connection.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderMessage = (message) => {
    if (message.role === 'user') {
      return (
        <View key={message.id} style={styles.messageBlock}>
          <Text style={styles.senderLabel}>Student</Text>
          <View style={styles.userBubble}>
            <Text style={styles.userText}>{message.content}</Text>
          </View>
        </View>
      );
    }

    return (
      <View key={message.id} style={styles.messageBlock}>
        <Text style={styles.senderLabel}>AI</Text>
        <MarkdownText text={message.content} style={styles.aiText} />
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />

      {/* ── Header ── */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Chat Demo</Text>
        <Text style={styles.headerSubtitle}>React Native + Groq API + Llama Model</Text>
      </View>

      {/* ── Messages ── */}
      <ScrollView
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
        keyboardShouldPersistTaps="handled"
      >
        {messages.map(renderMessage)}

        {isLoading && (
          <View style={styles.loadingRow}>
            <ActivityIndicator size="small" color="#007AFF" />
            <Text style={styles.loadingText}>AI is thinking…</Text>
          </View>
        )}
      </ScrollView>

      {/* ── Input Area ── */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.inputArea}>
          <TextInput
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Ask something about AI..."
            placeholderTextColor="#aaa"
            multiline
            returnKeyType="default"
            editable={!isLoading}
          />
          <TouchableOpacity
            style={[styles.sendButton, isLoading && styles.sendButtonDisabled]}
            onPress={sendMessage}
            disabled={isLoading}
            activeOpacity={0.85}
          >
            <Text style={styles.sendButtonText}>Ask AI</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#ffffff',
  },

  // Header
  header: {
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#ddd',
    backgroundColor: '#fff',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#111',
    letterSpacing: -0.3,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#888',
    marginTop: 3,
    letterSpacing: 0.1,
  },

  // Messages
  scrollView: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 8,
  },
  messageBlock: {
    marginBottom: 20,
  },
  senderLabel: {
    fontSize: 13,
    fontWeight: '700',
    color: '#333',
    marginBottom: 6,
  },

  // User bubble
  userBubble: {
    backgroundColor: '#DFF0FA',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
  },
  userText: {
    fontSize: 14,
    color: '#1a1a1a',
    lineHeight: 21,
  },

  // AI text
  aiText: {
    fontSize: 14,
    color: '#1a1a1a',
    lineHeight: 22,
  },

  // Loading
  loadingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  loadingText: {
    fontSize: 13,
    color: '#888',
    marginLeft: 8,
  },

  // Input
  inputArea: {
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#ddd',
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: Platform.OS === 'ios' ? 12 : 14,
    backgroundColor: '#fff',
  },
  textInput: {
    backgroundColor: '#f4f4f4',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 14,
    color: '#111',
    minHeight: 46,
    maxHeight: 120,
    marginBottom: 10,
    lineHeight: 20,
  },
  sendButton: {
    backgroundColor: '#1A73E8',
    borderRadius: 10,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    opacity: 0.55,
  },
  sendButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
});
