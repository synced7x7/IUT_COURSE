# AI Chat Demo 🤖
**React Native + Expo + Groq API + Llama Model**

A mobile chat app that lets users ask AI questions, powered by the Groq API running the Llama 3 model.

---

## 🚀 Setup & Run

### 1. Install dependencies
```bash
cd ai-chat-demo
npm install
```

### 2. Add your Groq API key
Open `App.js` and replace line 8:
```js
const GROQ_API_KEY = 'your_groq_api_key_here';
```
With your actual key from https://console.groq.com (free to sign up).

### 3. Start the app
```bash
npx expo start
```

Then scan the QR code with **Expo Go** on your phone:
- iOS → App Store: [Expo Go](https://apps.apple.com/app/expo-go/id982107779)
- Android → Play Store: [Expo Go](https://play.google.com/store/apps/details?id=host.exp.exponent)

---

## 📁 Project Structure
```
ai-chat-demo/
├── App.js          ← Main app (UI + Groq API logic)
├── app.json        ← Expo config
├── package.json    ← Dependencies
├── babel.config.js ← Babel config
└── README.md
```

## 🔑 Groq API
- Sign up free at https://console.groq.com
- Create an API key under "API Keys"
- Model used: `llama3-8b-8192` (fast and free tier)

## ✨ Features
- 💬 Real-time chat with Llama 3 via Groq
- 📝 Markdown **bold** text rendering
- ⌨️ Keyboard-aware layout
- 🔄 Loading indicator while AI responds
- 📜 Scrollable chat history
