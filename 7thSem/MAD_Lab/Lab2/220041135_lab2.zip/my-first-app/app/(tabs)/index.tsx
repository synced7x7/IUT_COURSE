import React, { useState, useRef } from 'react';
import {
  StyleSheet,
  TextInput,
  ActivityIndicator,
  View,
  Animated,
  Easing,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

import { ThemedText } from '@/components/themed-text';

export default function HomeScreen() {
  const [name, setName] = useState('');
  const [age, setAge] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [focused, setFocused] = useState(false);

  const resultOpacity = useRef(new Animated.Value(0)).current;
  const resultScale = useRef(new Animated.Value(0.9)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;

  const fetchAge = async () => {
    if (!name.trim()) {
      setError('Please enter a name');
      return;
    }

    setLoading(true);
    setError('');
    setAge(null);

    try {
      const response = await fetch(`https://api.agify.io?name=${encodeURIComponent(name)}`);
      const data = await response.json();

      if (data.age === null) {
        setError('Could not divine the essence for this creature');
      } else {
        setAge(data.age);
        // animate result in
        resultOpacity.setValue(0);
        resultScale.setValue(0.9);
        Animated.parallel([
          Animated.timing(resultOpacity, {
            toValue: 1,
            duration: 450,
            easing: Easing.out(Easing.cubic),
            useNativeDriver: true,
          }),
          Animated.spring(resultScale, {
            toValue: 1,
            friction: 6,
            useNativeDriver: true,
          }),
        ]).start();
      }
    } catch (err) {
      setError('Failed to fetch age. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient
      colors={['#0f172a', '#1e293b']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}>
      <View style={styles.box}>
        <ThemedText type="title" style={styles.title}>
          Essence Guesser
        </ThemedText>

        <TextInput
          style={[styles.input]}
          placeholder="Enter creature name"
          placeholderTextColor="#9aa4bb"
          value={name}
          onChangeText={setName}
          editable={!loading}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />

        <Pressable
          onPressIn={() => Animated.spring(buttonScale, { toValue: 0.96, useNativeDriver: true }).start()}
          onPressOut={() => Animated.spring(buttonScale, { toValue: 1, useNativeDriver: true }).start()}
          onPress={fetchAge}
          disabled={loading}
          style={{ width: '100%' }}>
          <Animated.View
            style={[
              styles.submitButton,
              loading && styles.submitButtonDisabled,
              { transform: [{ scale: buttonScale }] },
            ]}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <ThemedText style={styles.submitButtonText}>Guess the Essence</ThemedText>
            )}
          </Animated.View>
        </Pressable>

        {error ? <ThemedText style={styles.errorText}>{error}</ThemedText> : null}

        {age !== null && (
          <Animated.View
            style={[
              styles.resultContainer,
              { opacity: resultOpacity, transform: [{ scale: resultScale }] },
            ]}>
            <ThemedText type="subtitle">Essence Found</ThemedText>
            <ThemedText style={styles.ageText}>
              The essence of this creature is {age} years old
            </ThemedText>
          </Animated.View>
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  box: {
    width: '100%',
    maxWidth: 420,
    padding: 28,
    borderRadius: 16,
    backgroundColor: '#0b1020',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.04)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 12,
  },
  title: {
    marginBottom: 18,
    textAlign: 'center',
    color: '#e6eefc',
    fontSize: 26,
    fontWeight: '700',
  },
  input: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    borderRadius: 10,
    padding: 12,
    marginBottom: 14,
    fontSize: 16,
    color: '#e6eefc',
    backgroundColor: 'rgba(255,255,255,0.02)',
  },
  inputFocused: {
    borderColor: '#8b5cf6',
    shadowColor: '#7c3aed',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 8,
  },
  submitButton: {
    backgroundColor: '#7c3aed',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  errorText: {
    color: '#ff7b7b',
    marginBottom: 10,
    textAlign: 'center',
    fontWeight: '600',
    fontSize: 14,
  },
  resultContainer: {
    backgroundColor: 'rgba(124,58,237,0.08)',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: '#7c3aed',
    marginTop: 6,
  },
  ageText: {
    fontSize: 20,
    fontWeight: '700',
    marginTop: 6,
    color: '#c7b8ff',
  },
});
